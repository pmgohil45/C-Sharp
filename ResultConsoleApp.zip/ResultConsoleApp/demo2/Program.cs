﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace demo2
{

    class GetMark {

        public static string nm;
        public static int rlno, n1, n2, n3, n4;

        public void inputDetail() {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("Enter student roll number: ");
            rlno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter student name: ");
            nm = Console.ReadLine();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter marks of C# : ");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter marks of OS : ");
            n2 = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter marks of N/W : ");
            n3 = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Enter marks of JAVA : ");
            n4 = Convert.ToInt32(Console.ReadLine());
        }

    }
    class Print : GetMark {

        public void printing() {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n\nRoll Number: " + GetMark.rlno);
            Console.WriteLine("Student Name : " + GetMark.nm);
            Console.WriteLine("C# : " + GetMark.n1);
            Console.WriteLine("OS : " + GetMark.n2);
            Console.WriteLine("N/W : " + GetMark.n3);
            Console.WriteLine("JAVA : " + GetMark.n4);
        }
    }
    class ResultCalculation : Print
    {
        public static int total;
        public static int per;

        public void calculation() { 
            
            total = GetMark.n1 + GetMark.n2 + GetMark.n3 + GetMark.n4;
            
            per = Convert.ToInt32(total / 4);

            Console.ForegroundColor = ConsoleColor.Red;
            if(per <= 100 && per > 80){
               Console.WriteLine("Great : A+");
            }
            else if(per <= 80 && per > 70){
                Console.WriteLine("Great : B+");
            }
            else if (per <= 70 && per > 60)
            {
                Console.WriteLine("Great : C+");
            }
            else if (per <= 60 && per > 50)
            {
                Console.WriteLine("Great : D+");
            }
            else if (per <= 50 && per > 30)
            {
                Console.WriteLine("Result : Pass");
            }
            else if (per <= 30)
            {
                Console.WriteLine("Result : Fail");
            }


        }
    }
    class FinleResultPrint : ResultCalculation {
        public void finleResult() {

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Total of Subject : " + total);

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Percentage of Subject : " + per);
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            FinleResultPrint frp = new FinleResultPrint();
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.Clear();
            Console.Write("Enter a number of student : ");
            int n = Convert.ToInt32(Console.ReadLine());
            for (int i = 1; i <= n; i++)
            {
                frp.inputDetail();
                frp.printing();
                frp.calculation();
                frp.finleResult();
            }
            Console.ReadKey(true);
        }
    }
}
