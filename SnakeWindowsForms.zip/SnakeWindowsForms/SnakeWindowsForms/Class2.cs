﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeWindowsForms
{
    internal class Class2
    {
        public static int Width { get; set; }
        public static int Height { get; set; }
        public static string directions;
        public Class2()
        {
            Width = 30;
            Height = 30;
            directions = "left";

        }

    }
}