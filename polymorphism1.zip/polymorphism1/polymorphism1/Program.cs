﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polymorphism1
{
    /*
     * WAP to create student rgistration using polymorphism
     * student name, course, sem, div, roll no, number
     */
    public class a 
    {
        public String nm, c, d;
        public int sem, rlno, num;
        
    }
    public class b : a
    {
        public void stud() 
        {
            Console.WriteLine("Enter a Name : ");
            nm = Console.ReadLine();
            Console.WriteLine("Enter a Course : ");
            c = Console.ReadLine();
            Console.WriteLine("Enter a Semester : ");
            sem = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a Division : ");
            d = Console.ReadLine();
            Console.WriteLine("Enter a Roll Number: ");
            rlno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter a Number : ");
            num = Convert.ToInt32(Console.ReadLine());
        }
    }
    public class c : a 
    {
        public void stud() 
        {
            b b1 = new b();
            b1.stud();

            Console.WriteLine("Name : " + b1.nm);
            Console.WriteLine("Course : " + b1.c);
            Console.WriteLine("Semester : " + b1.sem);
            Console.WriteLine("Division : " + b1.d);
            Console.WriteLine("Roll Number : " + b1.rlno);
            Console.WriteLine("Number : " + b1.num);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            c c1 = new c();
            c1.stud();

            Console.Read();
        }
    }
}
