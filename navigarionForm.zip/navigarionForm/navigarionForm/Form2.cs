﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace navigarionForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                string ins = "insert into navigate values('" + txtName.Text + "')";
                SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cn);
                int a = sda.Fill(Class1.dt);
                if (a < 1)
                {
                    MessageBox.Show("Inserted");
                    clear();
                    nextCall();
                }
                else
                {
                    MessageBox.Show("Not Inserted");
                }
            }
            else
            {
                MessageBox.Show("Pleas, Enter a name...!");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear() {
            txtName.Text = "";
            txtName.Focus();
        }
        private void nextCall() {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
