﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace navigarionForm
{
    public partial class Form1 : Form
    {
        int currentReco = 0, totalReco = 0, flag = 0, f = 0;
        string oldName;

        public Form1()
        {
            InitializeComponent();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (f == 0)
            {
                txtName.Enabled = true;
                txtName.Enabled = true;
                f = 1;
            }
            else if (f == 1)
            {
                string ins = "insert into navigate values('" + txtName.Text + "')";
                SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cn);
                int a = sda.Fill(Class1.dt);
                if (a < 1)
                {    
                    MessageBox.Show(a.ToString());
                    MessageBox.Show("Data Succsessfuly Inserted..^_^");
                    txtName.Enabled = false;
                    display();
                    clear();
                }
                else
                {
                    MessageBox.Show("Not Inserted");
                }
            }
            else
            {
                MessageBox.Show("Pleas, Enter a name...!"); 
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            display();
        }
        private void display() {
            Class1.dt.Reset();
            string sel = "select * from navigate";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            sda.Fill(Class1.dt);
            Class1.dt.AcceptChanges();
            totalReco = Class1.dt.Rows.Count;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            display();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear() {
            txtName.Text = "";
            txtName.Focus();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (currentReco < totalReco - 1)
            {
                currentReco++;
                navigate();
            }
            else {
                MessageBox.Show("not show next");
            }
        }
        private void navigate() {
            if (totalReco >= 1)
            {
                txtName.Text = Class1.dt.Rows[currentReco]["Name"].ToString();
            }
            else {
                MessageBox.Show("No record found");
            }
        }
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (currentReco > 0)
            {
                currentReco--;
                navigate();
            }
            else {
                MessageBox.Show("Not work previous button");
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            currentReco = 0;
            navigate();
        }

        private void btnSecond_Click(object sender, EventArgs e)
        {
            currentReco = totalReco - 1;
            navigate();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtName.Text != "")
            {
                
                    string del = "delete from navigate where name='" + txtName.Text + "'";
                    SqlDataAdapter sda1 = new SqlDataAdapter(del, Class1.cn);
                    DataTable dt = new DataTable();
                    int a = sda1.Fill(dt);

                    if (a < 1)
                    {
                        totalReco--;
                        currentReco = 0;
                        clear();
                        MessageBox.Show("Deleted");
                        display();                        
                    }
                    else
                    {
                        MessageBox.Show("Not Delete");
                    }
            }
            else {
                MessageBox.Show("Text box is blank..!");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (flag == 0)
            {
                btnUpdate.Text = "Save";
                txtName.Enabled = true;
                oldName = txtName.Text;
                flag = 1;
            }
            else if (flag == 1)
            {
                string del = "update navigate set name='" + txtName.Text + "' where name='" + oldName + "'";
                SqlDataAdapter sda = new SqlDataAdapter(del, Class1.cn);
                DataTable dt = new DataTable(); 
                int a = sda.Fill(dt);
                MessageBox.Show(a.ToString());
                MessageBox.Show("Updated");
                clear();
                btnUpdate.Text = "Update";
                flag = 0;
                txtName.Enabled = false;                
                btnUpdate.Text = "Update";
                display();
            }
        }
        private void btnDispose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
