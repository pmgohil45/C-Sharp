﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructor
{
    // constructor
    class a {
        public a() 
        {
            Console.WriteLine("this is constructor of 'a' class");
        }
        public void demo() 
        {
            Console.WriteLine("demo of class 'a'");
        }
    }
    // inheritanc
    // polymorphism
    class b : a
    {
        public void b1(){
            Console.WriteLine("this is method b1");
        }
        public void demo()
        {
            Console.WriteLine("demo of class 'b'");
        }
    }
    class c : b {
        public void c1() {
            Console.WriteLine("this is methos c1");
        }
        public void demo()
        {
            Console.WriteLine("demo of class 'c'");
        }
        protected void protectDemo()
        {
            Console.WriteLine("this is protected methos of class 'c'");
        }
    }
    // Encapsulation
    class d : c 
    {
        public d() {
            Console.WriteLine("this is constructor of 'd' class");
        }
        private void privateDemo() {
            Console.WriteLine("this is private methos of class 'd'");
        }
        public void demo()
        {
            protectDemo();
            privateDemo();
            Console.WriteLine("demo of class 'd'");
        }
    }
    class Program 
    {
        static void Main(string[] args)
        {
            a a = new a();
            a.demo();
            b b = new b();
            b.demo();
            c c = new c();
            c.demo();
            d d = new d();
            d.demo();
            Console.Read();
        }
    }
}
